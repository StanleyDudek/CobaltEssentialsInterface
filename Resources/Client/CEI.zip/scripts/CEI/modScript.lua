load('CEI')
setExtensionUnloadMode('CEI', 'manual')
